import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-combat-center',
  templateUrl: './combat-center.component.html',
  styleUrls: ['./combat-center.component.css']
})
export class CombatCenterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
