export class Pokemon {
    url: string;
    name: string;
    sprites: string;
    id: number;
}