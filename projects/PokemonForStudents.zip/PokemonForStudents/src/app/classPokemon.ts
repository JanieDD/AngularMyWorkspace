export class classPokemon {
    id: number;
    name: string;
}