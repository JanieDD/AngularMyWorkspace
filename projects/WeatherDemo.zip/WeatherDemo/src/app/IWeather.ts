export interface IWeather {
    date: Date;
    description: string;
    icon: string;
    main: string;
    temperature: number;
}