export class Weather {
    id: number;
    name: string;
}
